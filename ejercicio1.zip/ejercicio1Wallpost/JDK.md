# Instalación de JDK

Para instalar un SDK soportado en su máquina pueden usar [SDK MAN](https://sdkman.io/install).

Ejemplos

```bash
sdk install java 11.0.2-open
sdk install java 11.0.11.hs-adpt
sdk install java 21.1.0.r16-grl
 
sdk use java 11.0.2-open
```
